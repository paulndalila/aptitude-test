const Footer = () => {
  return (
    <div className="footer">
      <p>Copyright &copy; 2024 | Hope_Kerubo Maseno University</p>
    </div>
  )
}

export default Footer