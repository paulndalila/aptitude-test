

const Bookmark = () => {
  return (
    <div>Bookmark(save) to view your unique quizes later!</div>
  )
}

export default Bookmark